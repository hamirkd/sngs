<table style="width: 100%; border-bottom: dashed 1px black;padding:5px 5px 5px 5px;">
    <tr style="vertical-align: top;">
        <td style="text-align: left;width: 100%; vertical-align: top;border:none;">
            <img src="../../public/images/header.png" alt="logo" style="height: 20mm"><br>
        </td>
    </tr>
</table>
