<table style="width: 100%; border-top: solid 1px black;">
    <tr>
        <td style="text-align: left;    width: 50%;border:none;"><?php echo NOM_STRUCT_ABBR;?></td>
        <td style="text-align: right;    width: 50%;border:none;">Imprime le <?php echo date('d/m/Y');?> - page [[page_cu]]/[[page_nb]]</td>
    </tr>
</table>