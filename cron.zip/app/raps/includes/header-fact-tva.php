<table style="width: 100%;" cellspacing="4mm" cellpadding="0">
        <tr> 
            <td style="width: 40%;vertical-align: top;text-align: left;">
                         &nbsp;
            </td>
             <td style="width: 20%"> 
            </td>
            <td style="width: 40%;text-align: right;">
                <strong><em>Ouagadougou, le <?php $dt=explode('-',$date);echo $dt[2]."/".$dt[1]."/".$dt[0]; echo " ".$heure;  ?></em></strong><br>
            </td>
        </tr>
</table>