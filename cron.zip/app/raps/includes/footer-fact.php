<!--<table style="width: 100%; border-top: solid 1px black;">
    <tr>
        <td style="text-align: left;    width: 50%;border:none;">SONGO-STOCK 2.3</td>
        <td style="text-align: right;    width: 50%;border:none;">Imprime le <?php echo date('d/m/Y');?> - page [[page_cu]]/[[page_nb]]</td>
    </tr>
</table> -->