<?php
$inventaire_date_code = date('Ymd');
echo $date;